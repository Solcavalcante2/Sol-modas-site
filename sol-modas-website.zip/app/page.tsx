import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Heart, ShoppingBag, Star, Truck, Shield, RefreshCw } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function HomePage() {
  const featuredProducts = [
    {
      id: 1,
      name: "Vestido Midi Elegante",
      price: "R$ 160,00",
      originalPrice: "R$ 249,90",
      image: "/placeholder.svg?height=300&width=250",
      rating: 4.8,
      reviews: 24,
      isNew: true,
    },
    {
      id: 2,
      name: "Cropped",
      price: "R$ 89,90",
      originalPrice: "R$ 119,90",
      image: "/placeholder.svg?height=300&width=250",
      rating: 4.9,
      reviews: 18,
      isNew: false,
    },
    {
      id: 3,
      name: "Calça Wide Leg Premium",
      price: "R$ 159,90",
      originalPrice: "R$ 199,90",
      image: "/placeholder.svg?height=300&width=250",
      rating: 4.7,
      reviews: 32,
      isNew: true,
    },
    {
      id: 4,
      name: "Conjunto Blazer + Saia",
      price: "R$ 299,90",
      originalPrice: "R$ 399,90",
      image: "/placeholder.svg?height=300&width=250",
      rating: 5.0,
      reviews: 15,
      isNew: false,
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-stone-100">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-stone-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="text-2xl">☀️</div>
              <h1 className="text-2xl font-bold text-stone-800">Sol Modas</h1>
            </div>

            <nav className="hidden md:flex items-center space-x-8">
              <Link href="#" className="text-stone-700 hover:text-amber-600 transition-colors">
                Início
              </Link>
              <Link href="#produtos" className="text-stone-700 hover:text-amber-600 transition-colors">
                Produtos
              </Link>
              <Link href="#sobre" className="text-stone-700 hover:text-amber-600 transition-colors">
                Sobre
              </Link>
              <Link href="#contato" className="text-stone-700 hover:text-amber-600 transition-colors">
                Contato
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" className="text-stone-700 hover:text-amber-600">
                <Heart className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-stone-700 hover:text-amber-600">
                <ShoppingBag className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-5xl md:text-6xl font-bold text-stone-800 mb-6">
              Desperte sua
              <span className="text-amber-600"> beleza</span> natural
            </h2>
            <p className="text-xl text-stone-600 mb-8 max-w-2xl mx-auto">
              Descubra peças únicas que realçam sua feminilidade com elegância e sofisticação. Moda que inspira
              confiança em cada momento.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-3">
                Ver Coleção
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-stone-300 text-stone-700 hover:bg-stone-50 px-8 py-3 bg-transparent"
              >
                Sobre Nós
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-white/50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Truck className="h-8 w-8 text-amber-600" />
              </div>
              <h3 className="text-lg font-semibold text-stone-800 mb-2">Frete Grátis</h3>
              <p className="text-stone-600">Acima de R$ 199 para todo Brasil</p>
            </div>
            <div className="text-center">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-amber-600" />
              </div>
              <h3 className="text-lg font-semibold text-stone-800 mb-2">Compra Segura</h3>
              <p className="text-stone-600">Pagamento 100% protegido</p>
            </div>
            <div className="text-center">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <RefreshCw className="h-8 w-8 text-amber-600" />
              </div>
              <h3 className="text-lg font-semibold text-stone-800 mb-2">Troca Fácil</h3>
              <p className="text-stone-600">30 dias para trocar ou devolver</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section id="produtos" className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-stone-800 mb-4">Produtos em Destaque</h2>
            <p className="text-stone-600 max-w-2xl mx-auto">
              Peças cuidadosamente selecionadas para realçar sua beleza única
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <Card
                key={product.id}
                className="group hover:shadow-lg transition-all duration-300 border-stone-200 bg-white/80 backdrop-blur-sm"
              >
                <CardContent className="p-0">
                  <div className="relative overflow-hidden rounded-t-lg">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      width={250}
                      height={300}
                      className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    {product.isNew && (
                      <Badge className="absolute top-3 left-3 bg-amber-600 hover:bg-amber-700">Novo</Badge>
                    )}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute top-3 right-3 bg-white/80 hover:bg-white text-stone-700"
                    >
                      <Heart className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="p-4">
                    <h3 className="font-semibold text-stone-800 mb-2 group-hover:text-amber-600 transition-colors">
                      {product.name}
                    </h3>

                    <div className="flex items-center mb-2">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${
                              i < Math.floor(product.rating) ? "text-amber-400 fill-current" : "text-stone-300"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-stone-500 ml-2">({product.reviews})</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-lg font-bold text-stone-800">{product.price}</span>
                        <span className="text-sm text-stone-500 line-through ml-2">{product.originalPrice}</span>
                      </div>
                    </div>

                    <Button className="w-full mt-3 bg-amber-600 hover:bg-amber-700 text-white">
                      Adicionar ao Carrinho
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button
              variant="outline"
              size="lg"
              className="border-amber-600 text-amber-600 hover:bg-amber-50 bg-transparent"
            >
              Ver Todos os Produtos
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="sobre" className="py-20 bg-gradient-to-r from-stone-100 to-amber-50">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-stone-800 mb-6">Sobre a Sol Modas ☀️</h2>
              <p className="text-stone-600 mb-6 text-lg leading-relaxed">
                Nascemos da paixão por realçar a beleza única de cada mulher. Na Sol Modas, acreditamos que a moda é uma
                forma de expressão pessoal e autoconfiança.
              </p>
              <p className="text-stone-600 mb-8 leading-relaxed">
                Cada peça é cuidadosamente selecionada pensando na qualidade, conforto e elegância que você merece.
                Nossa missão é iluminar seu dia com roupas que fazem você se sentir radiante como o sol.
              </p>
              <Button size="lg" className="bg-amber-600 hover:bg-amber-700 text-white">
                Conheça Nossa História
              </Button>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=500&width=400"
                alt="Sobre Sol Modas"
                width={400}
                height={500}
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 bg-stone-800">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Fique por dentro das novidades ☀️</h2>
          <p className="text-stone-300 mb-8 max-w-2xl mx-auto">
            Receba em primeira mão nossos lançamentos, promoções exclusivas e dicas de moda
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Seu melhor e-mail"
              className="flex-1 px-4 py-3 rounded-lg border border-stone-600 bg-stone-700 text-white placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-600"
            />
            <Button className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-3">Inscrever-se</Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-stone-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="text-2xl">☀️</div>
                <h3 className="text-xl font-bold">Sol Modas</h3>
              </div>
              <p className="text-stone-400 mb-4">Iluminando sua beleza com moda feminina de qualidade e elegância.</p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Links Rápidos</h4>
              <ul className="space-y-2 text-stone-400">
                <li>
                  <Link href="#" className="hover:text-amber-400 transition-colors">
                    Início
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-amber-400 transition-colors">
                    Produtos
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-amber-400 transition-colors">
                    Sobre
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-amber-400 transition-colors">
                    Contato
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Categorias</h4>
              <ul className="space-y-2 text-stone-400">
                <li>
                  <Link href="#" className="hover:text-amber-400 transition-colors">
                    Vestidos
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-amber-400 transition-colors">
                    Blusas
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-amber-400 transition-colors">
                    Calças
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-amber-400 transition-colors">
                    Conjuntos
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Contato</h4>
              <ul className="space-y-2 text-stone-400">
                <li>📧 contato@solmodas.com.br</li>
                <li>📱 (11) 99999-9999</li>
                <li>📍 São Paulo, SP</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-stone-800 mt-8 pt-8 text-center text-stone-400">
            <p>&copy; 2024 Sol Modas. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
